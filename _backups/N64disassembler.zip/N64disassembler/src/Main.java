import java.util.*;
import java.io.*;

public class Main{
	public static void main(String[] args){
		String path;
		/*
		System.out.println("Insert the path to rom: ");
		Scanner sc = new Scanner(System.in);
		path = sc.nextLine();
		System.out.flush();*/
		path = "/sdcard/n64prots/dkr.z64";
		String patho = "/sdcard/n64prots/dkrd.asm";
		System.out.println("Getting rom file from path '"+path+"'...");
		
		
		Disa64rom rom = new Disa64rom(new File(path));
		File out = new File(patho);
		try{
		out.createNewFile();
		}catch(Exception e){}
		rom.disassemblesToFile(out, 0x1000);
		
	}
}

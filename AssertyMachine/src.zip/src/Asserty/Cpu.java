package Asserty;
import java.nio.*;

public class Cpu{
	
	private Memory ram;
	private Memory rom;
	
	//Argumentos respectivamente:
	// Estoque: estado de máquina, e valores quaisquer
	private short[] mapper = new short[]{0, 0};
	int cmp1 = 0;
	int cmp2 = 0;
	
	int fmp = 0;
	
	IntBuffer regs;
	
	public Cpu(Memory mem){
		ram = mem;
		//rom = new Memory(0, new MemoryMapper(new int[]{0,0}));
		regs = IntBuffer.allocate(Regs.length);
	}
	//Reseta a cpu junto com a memória
	public void reset(){
		regs.clear();
		regs.put(Regs.stp, ram.map.Map[mapper[1]][1]-2);
		fmp = ram.map.Map[mapper[0]][1]-4;
		ram.reset();
	}
	//Carrega uma memória contendo instruções
	public void loadRom(Memory rom){
		this.rom = rom;
	}
	
	public void debug(){
		
		System.out.println(
		" * inp = 0x"+Integer.toHexString(getRegister32(Regs.inp))+"\n"+
		" * stp = 0x"+Integer.toHexString(getRegister32(Regs.stp))+"\n"+
		" * acu = 0x"+Integer.toHexString(getRegister32(Regs.acu))+"\n"+
		" * fmp = 0x"+Integer.toHexString(fmp)+"\n"+
		" * bkp = 0x"+Integer.toHexString(getRegister32(Regs.bkp))+"\n"+
		" * r1  = 0x"+Integer.toHexString(getRegister32(Regs.r1))+"\n"+
		" * r2  = 0x"+Integer.toHexString(getRegister32(Regs.r2))+"\n"+
		" * r3  = 0x"+Integer.toHexString(getRegister32(Regs.r3))+"\n"+
		" * r4  = 0x"+Integer.toHexString(getRegister32(Regs.r4))+"\n"+
		" * r5  = 0x"+Integer.toHexString(getRegister32(Regs.r5))+"\n"+
		" * r6  = 0x"+Integer.toHexString(getRegister32(Regs.r6))+"\n"+
		" * r7  = 0x"+Integer.toHexString(getRegister32(Regs.r7))+"\n"+
		" * r8  = 0x"+Integer.toHexString(getRegister32(Regs.r8))+"\n"+
		" * r9  = 0x"+Integer.toHexString(getRegister32(Regs.r9))+"\n"+
		" * ax  = 0x"+Integer.toHexString(getRegister32(Regs.ax))+"\n"+
		" * bx  = 0x"+Integer.toHexString(getRegister32(Regs.bx))+"\n"+
		" * cx  = 0x"+Integer.toHexString(getRegister32(Regs.cx))+"\n"+
		" * dx  = 0x"+Integer.toHexString(getRegister32(Regs.dx))+"\n-------------------------------------------------"
		);
		for(int i=0; i<256; i++){
			if((i%16)==0)
				System.out.println();
			System.out.print("0x"+((ram.get8(i))<16?"0":"")+Integer.toHexString(ram.get8(i))+" ");
		}
		System.out.println();
	}
	
	//Operações de requestação **********************************************************************
	//Só retornam valores na memória
	public int fetch8(){
		int byt = rom.get8(getRegister32(Regs.inp))&0xff;
		incRegister(Regs.inp);
		System.out.println("- fetch 8bits : 0x"+Integer.toHexString(byt));
		return byt;
		//byt;
	}
	public int fetch16(){
		int wrd = rom.get16(getRegister32(Regs.inp))&0xffff;
		addRegister(Regs.inp, 2);
		System.out.println("- fetch 16bits: 0x"+Integer.toHexString(wrd));
		return wrd;
	}
	public int fetch32(){
		int dwr = rom.get32(getRegister32(Regs.inp));
		addRegister(Regs.inp, 4);
		System.out.println("- fetch 32bits: 0x"+Integer.toHexString(dwr));
		return dwr;
	}
	public int fetchRegister8(){
		return getRegister8(fetch8());
	}
	public int fetchRegister16(){
		return getRegister16(fetch8());
	}
	public int fetchRegister32(){
		return getRegister32(fetch8());
	}
	public int fetchMemory8(){
		return ram.get8(fetch32(), 0);
	}
	public int fetchMemory16(){
		return ram.get16(fetch32(), 0);
	}
	public int fetchMemory32(){
		return ram.get32(fetch32(), 0);
	}
	public int fetchPointer8(){
		return ram.get8(fetchRegister32(), 0);
	}
	public int fetchPointer16(){
		return ram.get16(fetchRegister32(), 0);
	}
	public int fetchPointer32(){
		return ram.get32(fetchRegister32(), 0);
	}
	
	public int fetchExpression(){
		int res = 0;
		int opr;
		while(true){
			opr = fetch8();
			if(opr==ArithBank.end_exp)
				break;
			else{
				int next = opr>=8?fetchRegister16():fetch16();
				opr = opr%8;
				switch(opr){
					case ArithBank.plus:
						res+=next;
						break;
					case ArithBank.mnus:
						res-=next;
						break;
					case ArithBank.mult:
						res*=next;
						break;
					case ArithBank.and:
						res&=next;
						break;
					case ArithBank.or:
						res|=next;
						break;
					case ArithBank.xor:
						res^=next;
						break;
					default:
						break;
				}
			}
		}
		return res;
	}
	
	//***********REGISTROS E MANIPULAÇÃO******
	//Setter
	public void setRegister(int r, int v){
		regs.put(r, v&0xfffffff);
	}
	//Getters
	public int getRegister32(int r){
		return regs.get(r);
	}
	public int getRegister16(int r){
		return regs.get(r)&0xffff;
	}
	public int getRegister8(int r){
		return regs.get(r)&0xff;
	}
	
	//Operadores aritméticos
	public void incRegister(int r){
		setRegister(r, getRegister32(r)+1);
	}
	public void decRegister(int r){
		setRegister(r, getRegister32(r)-1);
	}
	public void addRegister(int r, int value){
		setRegister(r, getRegister32(r)+value);
	}
	public void subRegister(int r, int value){
		setRegister(r, getRegister32(r)-value);
	}
	public void mulRegister(int r, int value){
		setRegister(r, getRegister32(r)*value);
	}
	public void divRegister(int r, int value){
		setRegister(r, getRegister32(r)/value);
	}
	public void modRegister(int r, int value){
		setRegister(r, getRegister32(r)%value);
	}
	//Operadores lógicos
	public void andRegister(int r, int value){
		setRegister(r, getRegister32(r)&value);
	}
	public void orRegister(int r, int value){
		setRegister(r, getRegister32(r)|value);
	}
	public void xorRegister(int r, int value){
		setRegister(r, getRegister32(r)^value);
	}
	public void lsfRegister(int r, int value){
		setRegister(r, getRegister32(r)<<value);
	}
	public void rsfRegister(int r, int value){
		setRegister(r, getRegister32(r)>>value);
	}
	public void notRegister(int r){
		setRegister(r, ~getRegister32(r));
	}
	
	public int getBankMemory(){
		return getRegister32(Regs.bkp);
	}
	
	//Estocamento de qualquer valor
	public void pushStack(int lit){
		ram.set16(lit, getRegister32(Regs.stp), mapper[1]);
		subRegister(Regs.stp, 2);
	}
	public int popStack(){
		addRegister(Regs.stp, 2);
		return ram.get16(getRegister32(Regs.stp), mapper[1]);
	}
	
	//Estocamento de estado de máquina
	private void push(int lit){
		ram.set32(lit, fmp, mapper[0]);
		fmp -= 4;
	}
	private int pop(){
		fmp += 4;
		return ram.get32(fmp, mapper[0]);
	}
	public void pushState(){
		for(int i=0; i<Regs.length; i++)
			push(regs.get(i));
	}
	public void popState(){
		for(int i=Regs.length-1; i>-1; i--)
			regs.put(i, pop());
	}
	
	//Operações internas
	public void jump(int address) {
		setRegister(Regs.inp, address);
	}
	
	//Executa uma instrução
	//A Execução pode retornar valores inteiros que
	//representam a situação, retornar 1, o programa
	//foi finalizado com sucesso, retonar 0, o programa
	//foi finalizado com erro, retornar -1, o programa
	//não soube como encerrar (acabou caindo em um ponto
	//onde não existe código) talvez com cortes e
	//limitações para otimizar
	private int execute(int opr){
		System.out.println("*******Instruction: 0x"+Integer.toHexString(opr)+"*******");
		if(getRegister32(Regs.inp)>=rom.length)
			return -1;
		
		switch(opr){
			
				//****INSTRUÇÕES DE REGISTROS
			
			case Ints.mov_lit_reg:{
					int val = fetch16();
					int reg = fetch8();
					setRegister(reg, val);
				}
				break;
			case Ints.mov_reg_reg:{
					int val = fetchRegister16();
					int reg = fetch8();
					setRegister(reg, val);
				}
				break;
			case Ints.mov_reg_mem:{
					int val = fetchRegister16();
					int mem = fetch32();
					ram.set16(val, mem, getBankMemory());
				}
				break;
			case Ints.mov_mem_reg:{
					int val = fetchMemory16();
					int reg = fetch8();
					setRegister(reg, val);
				}
				break;
			case Ints.mov_lit_mem:{
					int val = fetch16();
					int mem = fetch32();
					ram.set16(val, mem, getBankMemory());
				}
				break;
			case Ints.mov_reg_ptr:{
					int val = fetchRegister16();
					int ptr = fetchRegister32();
					ram.set16(val, ptr, getBankMemory());
				}
				break;
			case Ints.mov_ptr_reg:{
					int val = fetchPointer16();
					int reg = fetch8();
					setRegister(reg, val);
				}
				break;
			case Ints.mov_lit_ptr:{
					int val = fetch16();
					int ptr = fetchRegister32();
					ram.set16(val, ptr, getBankMemory());
				}
				break;
			case Ints.mov_exp_reg:{
					int val = fetchExpression();
					int reg = fetch8();
					setRegister(reg, val);
				}
				break;
			case Ints.mov_exp_mem:{
					int val = fetchExpression();
					int mem = fetch32();
					ram.set16(val, mem, getBankMemory());
				}
				break;
			case Ints.mov_exp_ptr:{
					int val = fetchExpression();
					int ptr = fetchRegister32();
					ram.set16(val, ptr, getBankMemory());
				}
				break;
			case Ints.mov8_mem_reg:{
					int val = fetchMemory8();
					int reg = fetch8();
					setRegister(reg, val);
				}
				break;
			case Ints.mov8_ptr_reg:{
					int val = fetchPointer8();
					int reg = fetch8();
					setRegister(reg, val);
				}
				break;
			case Ints.mov8_reg_mem:{
					int val = fetchRegister8();
					int mem = fetch32();
					ram.set8(val, mem, getBankMemory());
				}
				break;
			case Ints.mov8_reg_ptr:{
					int val = fetchRegister8();
					int ptr = fetchRegister32();
					ram.set8(val, ptr, getBankMemory());
				}
				break;
			case Ints.mov32_mem_reg:{
					int val = fetchMemory32();
					int reg = fetch8();
					setRegister(reg, val);
				}
				break;
			case Ints.mov32_ptr_reg:{
					int val = fetchPointer32();
					int reg = fetch8();
					setRegister(reg, val);
				}
				break;
			case Ints.mov32_reg_mem:{
					int val = fetchRegister32();
					int mem = fetch32();
					ram.set32(val, mem, getBankMemory());
				}
				break;
			case Ints.mov32_reg_ptr:{
					int val = fetchRegister32();
					int ptr = fetchRegister32();
					ram.set32(val, ptr, getBankMemory());
				}
				break;
			
				//****INSTRUÇÕES DE ESTOCAMENTO
			
			case Ints.psh_lit:{
					int val = fetch16();
					pushStack(val);
				}
				break;
			case Ints.psh_reg:{
					int val = fetchRegister16();
					pushStack(val);
				}
				break;
			case Ints.psh_mem:{
					int val = fetchMemory16();
					pushStack(val);
				}
				break;
			case Ints.psh_ptr:{
					int val = fetchPointer16();
					pushStack(val);
				}
				break;
			case Ints.pop_reg:{
					int reg = fetch8();
					setRegister(reg, popStack());
				}
				break;
			
				//****INSTRUÇÕES ARITMÉTICAS
			
			case Ints.add_lit_reg:{
					int lit = fetch16();
					int reg = fetch8();
					addRegister(reg, lit);
				}
				break;
			case Ints.add_reg_reg:{
					int lit = fetchRegister16();
					int reg = fetch8();
					addRegister(reg, lit);
				}
				break;
			case Ints.sub_lit_reg:{
					int lit = fetch16();
					int reg = fetch8();
					subRegister(reg, lit);
				}
				break;
			case Ints.sub_reg_reg:{
					int lit = fetchRegister16();
					int reg = fetch8();
					subRegister(reg, lit);
				}
				break;
			case Ints.mul_lit_reg:{
					int lit = fetch16();
					int reg = fetch8();
					mulRegister(reg, lit);
				}
				break;
			case Ints.mul_reg_reg:{
					int lit = fetchRegister16();
					int reg = fetch8();
					mulRegister(reg, lit);
				}
				break;
			case Ints.div_lit_reg:{
					int lit = fetch16();
					int reg = fetch8();
					divRegister(reg, lit);
				}
				break;
			case Ints.div_reg_reg:{
					int lit = fetchRegister16();
					int reg = fetch8();
					divRegister(reg, lit);
				}
				break;
			case Ints.odiv_lit_reg:{
					int lit = fetch16();
					int reg = fetch8();
					modRegister(reg, lit);
				}
				break;
			case Ints.odiv_reg_reg:{
					int lit = fetchRegister16();
					int reg = fetch8();
					modRegister(reg, lit);
				}
				break;
			case Ints.inc_reg:{
					int reg = fetch8();
					incRegister(reg);
				}
				break;
			case Ints.dec_reg:{
					int reg = fetch8();
					decRegister(reg);
				}
				break;

				//****INSTRUÇÕES A BIT
				
			case Ints.lsf_lit_reg:{
					int lit = fetch16();
					int reg = fetch8();
					lsfRegister(reg, lit);
				}
				break;
			case Ints.lsf_reg_reg:{
					int lit = fetchRegister16();
					int reg = fetch8();
					lsfRegister(reg, lit);
				}
				break;
			case Ints.rsf_lit_reg:{
					int lit = fetch16();
					int reg = fetch8();
					rsfRegister(reg, lit);
				}
				break;
			case Ints.rsf_reg_reg:{
					int lit = fetchRegister16();
					int reg = fetch8();
					rsfRegister(reg, lit);
				}
				break;
			case Ints.and_lit_reg:{
					int lit = fetch16();
					int reg = fetch8();
					andRegister(reg, lit);
				}
				break;
			case Ints.and_reg_reg:{
					int lit = fetchRegister16();
					int reg = fetch8();
					andRegister(reg, lit);
				}
				break;
			case Ints.or_lit_reg:{
					int lit = fetch16();
					int reg = fetch8();
					orRegister(reg, lit);
				}
				break;
			case Ints.or_reg_reg:{
					int lit = fetchRegister16();
					int reg = fetch8();
					orRegister(reg, lit);
				}
				break;
			case Ints.xor_lit_reg:{
					int lit = fetch16();
					int reg = fetch8();
					xorRegister(reg, lit);
				}
				break;
			case Ints.xor_reg_reg:{
					int lit = fetchRegister16();
					int reg = fetch8();
					xorRegister(reg, lit);
				}
				break;
			case Ints.not_reg:{
					int reg = fetch8();
					notRegister(reg);
				}
				break;
			
				//****INSTRUÇÕES DE PULO E CONDICIONAMENTOS
				
			case Ints.jmp_mem:{
					int lit = fetch32();
					jump(lit);
				}
				break;
			case Ints.jmp_ptr:{
					int lit = fetchPointer32();
					jump(lit);
				}
				break;
			case Ints.cmp_lit_reg:{
					int lit = fetch16();
					int reg = fetchRegister16();
					cmp1 = lit; cmp2 = reg;
				}
				break;
			case Ints.cmp_reg_reg:{
					int reg1 = fetchRegister16();
					int reg2 = fetchRegister16();
					cmp1 = reg1; cmp2 = reg2;
				}
				break;
			case Ints.jet_mem:{
					int mem = fetch32();
					if(cmp1==cmp2)
						jump(mem);
				}
				break;
			case Ints.jet_ptr:{
					int mem = fetchPointer32();
					if(cmp1==cmp2)
						jump(mem);
				}
				break;
			case Ints.jne_mem:{
					int mem = fetch32();
					if(cmp1!=cmp2)
						jump(mem);
				}
				break;
			case Ints.jne_ptr:{
					int mem = fetchPointer32();
					if(cmp1!=cmp2)
						jump(mem);
				}
				break;
			case Ints.jgt_mem:{
					int mem = fetch32();
					if(cmp1>cmp2)
						jump(mem);
				}
				break;
			case Ints.jgt_ptr:{
					int mem = fetchPointer32();
					if(cmp1>cmp2)
						jump(mem);
				}
				break;
			case Ints.jlt_mem:{
					int mem = fetch32();
					if(cmp1<cmp2)
						jump(mem);
				}
				break;
			case Ints.jlt_ptr:{
					int mem = fetchPointer32();
					if(cmp1<cmp2)
						jump(mem);
				}
				break;
			case Ints.jge_mem:{
					int mem = fetch32();
					if(cmp1>=cmp2)
						jump(mem);
				}
				break;
			case Ints.jge_ptr:{
					int mem = fetchPointer32();
					if(cmp1>=cmp2)
						jump(mem);
				}
				break;
			case Ints.jle_mem:{
					int mem = fetch32();
					if(cmp1<=cmp2)
						jump(mem);
				}
				break;
			case Ints.jle_ptr:{
					int mem = fetchPointer32();
					if(cmp1<=cmp2)
						jump(mem);
				}
				break;

				//****INSTRUÇÕES E CHAMADAS DE SUB-ROTINAS
			
			case Ints.call_mem:{
					int lit = fetch32();
					pushState();
					jump(lit);
				}
				break;
			case Ints.call_ptr:{
					int lit = fetchPointer32();
					pushState();
					jump(lit);
				}
				break;
			case Ints.ret:{
					popState();
				}
				break;

				//****INSTRUÇÕES DE MANIPULAÇÃO DE MULTI-DADOS
			
			case Ints.dl_mem_lits:{
					int mem = fetch32();
					int length = fetch16()*2;
					for(int i=0; i<length; i+=2)
						ram.set16(fetch16(), mem+i);
				}
				break;
			case Ints.dl_ptr_lits:{
					int mem = fetchPointer32();
					int length = fetch16()*2;
					for(int i=0; i<length; i+=2)
						ram.set16(fetch16(), mem+i);
				}
				break;
			case Ints.dl8_mem_lits:{
					int mem = fetch32();
					int length = fetch16();
					for(int i=0; i<length; i++)
						ram.set8(fetch8(), mem+i);
				}
				break;
			case Ints.dl8_ptr_lits:{
					int mem = fetchPointer32();
					int length = fetch16();
					for(int i=0; i<length; i++)
						ram.set8(fetch8(), mem+i);
				}
				break;
			case Ints.dl32_mem_lits:{
					int mem = fetch32();
					int length = fetch16()*4;
					for(int i=0; i<length; i+=4)
						ram.set32(fetch32(), mem+i);
				}
				break;
			case Ints.dl32_ptr_lits:{
					int mem = fetchPointer32();
					int length = fetch16()*4;
					for(int i=0; i<length; i+=4)
						ram.set32(fetch32(), mem+i);
				}
				break;

				//****INSTRUÇÕES ESPECIAIS
			
			case Ints.int_lit:{
					
				}
				break;
			
			default:{
					
				}
		}
		return 1;
	}
	//Continua executando
	public int step(){
		int opr = fetch8();
		System.out.println("**********************************INSTRUCTION*************************************");
		int sucess = execute(opr);
		debug();
		return sucess;
	}
	
}


package Asserty;

public class Asserty
{
}

package Asserty;

public class MemoryMapper{
	public int[][] Map;
	public MemoryMapper(int[] data){
		int size = 0;
		if(data.length%2==0){
			size = data.length/2;
			Map = new int[size][2];
			for(int offset=0; offset<data.length; offset+=2){
				Map[offset/2][0] = data[offset];
				Map[offset/2][1] = data[offset+1];
			}
		}else{
			Map = new int[0][0];
		}
	}
	public int getOffset(int offset, int map){
		offset &= 0xfffffff;//offset<0?Map[map][1]+offset:offset;
		return Map[map][0]+(offset%Map[map][1]);
	}
}

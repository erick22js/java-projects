package Asserty;
import java.nio.*;

public class Memory{
	//Buffer de memória para acesso
	ByteBuffer buffer;
	MemoryMapper map;
	MemoryMapper entirely;
	int length;
	
	public Memory(int size, MemoryMapper mapper){
		buffer = ByteBuffer.allocate(size);
		length = size;
		map = mapper;
		entirely = new MemoryMapper(new int[]{0, length});
		buffer.order(ByteOrder.LITTLE_ENDIAN);
	}
	public Memory(byte[] data, MemoryMapper mapper){
		buffer = ByteBuffer.wrap(data);
		length = data.length;
		map = mapper;
		entirely = new MemoryMapper(new int[]{0, length});
		buffer.order(ByteOrder.LITTLE_ENDIAN);
	}
	
	//MAPEADO
	//Definir valores de 8 bits
	public void set8(byte value, int p, int m){
		buffer.put(map.getOffset(p, m), value);
	}
	public void set8(int value, int p, int m){
		buffer.put(map.getOffset(p, m), (byte)value);
	}
	//Definir valores de 16 bits
	public void set16(Short value, int p, int m){
		buffer.putShort(map.getOffset(p, m), value);
	}
	public void set16(int value, int p, int m){
		buffer.putShort(map.getOffset(p, m), (short)value);
	}
	//Definir valores de 32 bits
	public void set32(int value, int p, int m){
		buffer.putInt(map.getOffset(p, m), value);
	}
	
	//Obtém valores de 8 bits
	public int get8(int p, int m){
		return buffer.get(map.getOffset(p, m))&0xff;
	}
	//Obtém valores de 16 bits
	public int get16(int p, int m){
		return buffer.getShort(map.getOffset(p, m))&0xffff;
	}
	//Obtém valores de 64 bits
	public int get32(int p, int m){
		return buffer.getInt(map.getOffset(p, m));
	}
	
	//NÃO MAPEADO
	//Definir valores de 8 bits
	public void set8(byte value, int p){
		buffer.put(entirely.getOffset(p, 0), value);
	}
	public void set8(int value, int p){
		buffer.put(entirely.getOffset(p, 0), (byte)value);
	}
	//Definir valores de 16 bits
	public void set16(Short value, int p){
		buffer.putShort(entirely.getOffset(p, 0), value);
	}
	public void set16(int value, int p){
		buffer.putShort(entirely.getOffset(p, 0), (short)value);
	}
	//Definir valores de 32 bits
	public void set32(int value, int p){
		buffer.putInt(entirely.getOffset(p, 0), value);
	}

	//Obtém valores de 8 bits
	public int get8(int p){
		return buffer.get(entirely.getOffset(p, 0))&0xff;
	}
	//Obtém valores de 16 bits
	public int get16(int p){
		return buffer.getShort(entirely.getOffset(p, 0))&0xffff;
	}
	//Obtém valores de 64 bits
	public int get32(int p){
		return buffer.getInt(entirely.getOffset(p, 0));
	}
	
	public int size(){
		return length;
	}
	
	//Opção para limpar(resetar) a memória
	public void reset(){
		buffer.clear();
	}
	
	//Este retorna os bytes da memória
	public byte[] getBytes(){
		return buffer.array();
	}
}

package Asserty;

public class ArithBank{
	final public static byte plus = 0x00;
	final public static byte mnus = 0x01;
	final public static byte mult = 0x02;
	final public static byte and = 0x03;
	final public static byte or = 0x04;
	final public static byte xor = 0x05;
	final public static byte not = 0x06;
	
	final public static byte bgn_exp = 0x07;
	final public static byte end_exp = 0x0f;
}

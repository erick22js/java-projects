import Asserty.compiler.*;
import Asserty.*;
import java.nio.*;

public class Main
{
	public static void main(String[] args)
	{
		
		String text = 
			"main:"+"\n"+
			"	mov 8, r4"+"\n"+
			"	jmp %loop"+"\n"+
			"	"+"\n"+
			"loop:"+"\n"+
			"	sub 1, r4"+"\n"+
			"	add 1, r2"+"\n"+
			"	cmp 0, r4"+"\n"+
			"	jne %loop"+"\n"+
			"	jmp %end"+"\n"+
			"end:"+"\n"+
			"	mov 3, r3"
			
		;
			/*"struct Rectangle{"+"\n"+
			"	x:0"+"\n"+
			"	y:2"+"\n"+
			"	w:4"+"\n"+
			"	h:6"+"\n"+
			"}"+"\n"+
			"struct Rectangle2{"+"\n"+
			"	x:0"+"\n"+
			"	y:2"+"\n"+
			"	w:4"+"\n"+
			"	h:10"+"\n"+
			"}"+"\n"+
			"define val 0x20"+"\n"+
			"main:"+"\n"+
			"	mov [10+8], <Rectangle>%val.h"+"\n"+
			"	mov <Rectangle>%val.h, r1"+"\n"+
			"	psh %r2"+"\n"+
			"	mov 3, r2"+"\n"+
			"	mov [r2+5], r4";*/
		;
		AssertyParser parser = new AssertyParser();
		AssertyCompiler compiler = new AssertyCompiler();
		byte[] bin = null;
		try {
			JsonObj map = parser.parseMap(AssertyParser.bakeTokens(text));
			System.out.println(map.toString(2));
			bin = compiler.compile(map);
			for(int i=0; i<bin.length; i++){
				if(i%16==0)
					System.out.print("\n0x"+(i>0xfff?"":i>0xff?"0":i>0xf?"00":"000")+Integer.toHexString(i)+" =>");
				System.out.print(" 0x"+(Integer.toHexString(bin[i]&0xff)));
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		
		
		System.out.println(("-").codePointAt(0));
		MemoryMapper mapper = new MemoryMapper(new int[]{
			0x0000, 0xff
		});
		
		Memory ram = new Memory(0xff, mapper); //16kb
		Cpu machine = new Cpu(ram); //nossa cpu
		
		Memory rom = new Memory(bin, mapper); //gerando cartucho 
		
		int i=0;
		
		
		
		System.out.println("Dados da rom:");
		for(int p=0; p<rom.size(); p++){
			if(p%16==0)
				System.out.println();
			System.out.print("0x"+Integer.toHexString(rom.get8(p)&0xff)+" ");
		}
		
		System.out.println("\n\n");
		
		
		machine.loadRom(rom);
		machine.reset();
		
		while(machine.step()>=0){}
		//machine.step();
		//machine.step();
		//machine.step();
		//machine.step();
		
		MemoryMapper map = new MemoryMapper(new int[]{
			000, 100,
			100, 050,
			150, 230,
		});
		
		IntBuffer fubb = IntBuffer.allocate(5);
		Integer inte = 0x0000000f;
		//inte = inte/4;
		
		System.out.println(inte&0xfffffff);
			//map.getOffset(101, 0));*/
		
	}
}
